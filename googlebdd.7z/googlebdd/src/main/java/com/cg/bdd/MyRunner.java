package com.cg.bdd;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= "C:\\Users\\akshkk\\Desktop\\selenium\\googlebdd\\features\\search.feature", glue="stepDefinitions")
public class MyRunner {

}
